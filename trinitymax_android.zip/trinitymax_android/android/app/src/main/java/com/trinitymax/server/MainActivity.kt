package com.trinitymax.server

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val status = findViewById<TextView>(R.id.statusText)
        status.text = "Starting TrinityMax server..."

        RustBridge().startServer()

        status.text = "TrinityMax running on TCP 25565 / UDP 19132"
    }
}
