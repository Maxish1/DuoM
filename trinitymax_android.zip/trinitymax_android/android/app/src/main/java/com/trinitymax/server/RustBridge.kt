package com.trinitymax.server

class RustBridge {
    companion object {
        init {
            System.loadLibrary("trinitymax")
        }
    }

    external fun startServer()
}
