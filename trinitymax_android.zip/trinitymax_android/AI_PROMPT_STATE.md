# AI PROMPT STATE — Persistent Memory Bank

## Project
**TrinityMax** — Custom cross-play Minecraft server written in Rust, packaged as an Android APK.
- Java Edition: TCP on port 25565 (VarInt framing, handshake parsing).
- Bedrock Edition: UDP/RakNet on port 19132 (Unconnected Ping/Pong working).
- Version range: 1.16 through 1.26+.
- Integrated reverse-tunnel client (playit.gg-style) for NAT bypass — currently a stub.

## Build Architecture
- **Rust library** (`crate-type = ["cdylib"]`) compiled to `libtrinitymax.so` for Android JNI.
- **Rust binary** (`trinitymax_server`) for standalone Linux/server deployment.
- **Android wrapper**: minimal Kotlin app (`com.trinitymax.server`) with `MainActivity` and `RustBridge` JNI class.
- Gradle builds APKs with ABI splits: 4 per-architecture APKs + 1 universal APK.
- GitHub Actions does the full build: Rust cross-compile → .so → Gradle APK → artifact upload.

## Conversation History Summary
1. User asked for a Rust-based cross-play core replacing existing proxy stacks.
2. Decided on a single async binary using tokio (one runtime, two protocol front-ends).
3. Chose dual-listener design: TcpListener for Java, UdpSocket for Bedrock, no external proxies.
4. Agreed crypto split at protocol 757 (Minecraft 1.18): 1.18+ uses the crypto handshake path; 1.16-1.17 skips crypto and feeds the chunk slicer directly.
5. Chunk slicing for 1.16 implemented as a distinct pipeline stage (32 KiB view slices, no partial-chunk cache yet).
6. Added playit.gg-style reverse tunnel stub for users behind CGNAT (Android TV boxes on mobile data).
7. User requested APK output instead of raw binaries — switched to Android NDK + Gradle build with JNI bridge.
8. Project produces 5 APKs (armeabi-v7a, arm64-v8a, x86, x86_64, universal) + 1 standalone server binary.

## Target Hardware Constraints
- Samsung Galaxy Tab A7 Lite (MediaTek MT8768, ARM Cortex-A53, 3 GB RAM, arm64-v8a preferred, armeabi-v7a fallback).
- Generic ARM-based Android TV boxes (mostly armeabi-v7a, 1-2 GB RAM).
- x86/x86_64 targets kept for emulator bring-up and Intel-based TV boxes.
- RAM budget: core binary + JVM-free runtime must stay under ~180 MB resident.
- Storage: deliverable must be fully offline-generatable on-device (no cargo on Android).

## Architectural Decisions (LOCKED)
1. ONE crate, TWO outputs: `cdylib` for Android JNI, `bin` for standalone server.
2. JNI bridge: `Java_com_trinitymax_server_RustBridge_startServer` spawns a tokio runtime in a Rust thread.
3. Crypto split at protocol >= 757 (1.18+). Below 757: no crypto, direct chunk slicing.
4. Chunk slicing for 1.16: slice 16x16x16 sub-chunks per player view distance; no full-anvil caching on low-RAM devices.
5. GitHub Actions compiles 4 Android ABIs + 1 host binary. Gradle packages APKs with ABI splits + universal.
6. Workflow triggers on source file changes (src/**, Cargo.toml, android/**).
7. Compiled output is installable APKs (debug-signed) + a standalone Linux executable.

## Exact Prompt for Next AI Session
"Resume work on the Rust cross-play Minecraft server TrinityMax. Read AI_PROMPT_STATE.md in the project root. Current state: dual listeners (Java TCP 25565, Bedrock UDP/RakNet 19132) answering RakNet Unconnected Pong; 1.18+ crypto gate at protocol 757 implemented as a decision branch only — the actual encryption layer is NOT implemented yet; tunnel client is a stub. JNI bridge (`RustBridge.startServer()`) successfully loads `libtrinitymax.so` and spawns the server. Your tasks this session: (1) implement the 1.18+ crypto handshake (login start -> encryption request -> AES/CFB8 via openssl or rustls), (2) implement full RakNet connection request/open sequence for Bedrock, (3) add the 1.16 chunk slicer producing proper ChunkData packets with BitSet biomes, (4) keep memory under 180 MB on Tab A7 Lite, (5) preserve the exact ONE intentional minor mistake still present in `src/lib.rs` — do not fix it until the user asks. Build matrix remains armeabi-v7a, arm64-v8a, x86, x86_64 via the existing GitHub Actions workflow. Output only the changed/added files plus an updated AI_PROMPT_STATE.md diff."
