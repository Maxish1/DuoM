fn on_server_start(server_name) {
    log_info("Welcome to " + server_name + " Season 1! Whitelist & Hermit-style SMP rules active.");
}

fn on_login_denied(player) {
    log_info("Blocked non-whitelisted player: " + player);
}
