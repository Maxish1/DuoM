use std::net::SocketAddr;
use std::os::raw::c_void;
use std::sync::Arc;
use std::time::Duration;

use anyhow::Result;
use tokio::io::AsyncReadExt;
use tokio::net::{TcpListener, TcpStream, UdpSocket};
use tokio::time::sleep;

const JAVA_TCP_PORT: u16 = 25565;
const BEDROCK_UDP_PORT: u16 = 19132;
const SERVER_GUID: u64 = 0x54524E4954594D58;

const RAKNET_MAGIC: [u8; 16] = [
    0x00, 0xff, 0xff, 0x00, 0xfe, 0xfe, 0xfe, 0xfe,
    0xfd, 0xfd, 0xfd, 0xfd, 0x12, 0x34, 0x56, 0x78,
];

fn requires_1_18_plus_crypto(protocol_version: i32) -> bool {
    protocol_version >= 757
}

pub fn start_server_internal() {
    std::thread::spawn(|| {
        let rt = tokio::runtime::Runtime::new().unwrap();
        rt.block_on(async {
            if let Err(e) = run_server().await {
                eprintln!("[trinitymax] fatal server error: {}", e);
            }
        });
    });
}

#[no_mangle]
pub extern "C" fn Java_com_trinitymax_server_RustBridge_startServer(
    _env: *mut c_void,
    _this: *mut c_void,
) {
    start_server_internal();
}

async fn run_server() -> Result<()> {
    println!("[trinitymax] booting cross-play server core...");
    println!("[trinitymax] java tcp    on :{}", JAVA_TCP_PORT);
    println!("[trinitymax] bedrock udp on :{}", BEDROCK_UDP_PORT);

    let tcp = tokio::spawn(run_java_tcp());
    let udp = tokio::spawn(run_bedrock_udp());
    let tunnel = tokio::spawn(run_tunnel_client());

    tcp.await??;
    udp.await??;
    tunnel.await??;
    Ok(())
}

async fn run_java_tcp() -> Result<()> {
    let listener = TcpListener::bind(("0.0.0.0", JAVA_TCP_PORT)).await?;
    loop {
        let (socket, peer) = listener.accept().await?;
        tokio::spawn(handle_java_connection(socket, peer));
    }
}

async fn handle_java_connection(mut socket: TcpStream, peer: SocketAddr) -> Result<()> {
    socket.set_nodelay(true)?;
    let mut buf = [0u8; 512];
    let n = socket.read(&mut buf).await?;
    if n == 0 {
        return Ok(());
    }

    let mut pos = 0usize;
    let _packet_len = match read_varint(&buf[..n], &mut pos) {
        Some(v) => v,
        None => return Ok(()),
    };
    let packet_id = match read_varint(&buf[..n], &mut pos) {
        Some(v) => v,
        None => return Ok(()),
    };

    if packet_id == 0x00 {
        let protocol = match read_varint(&buf[..n], &mut pos) {
            Some(v) => v,
            None => return Ok(()),
        };
        if requires_1_18_plus_crypto(protocol) {
            println!("[java] {} protocol {} -> 1.18+ crypto path", peer, protocol);
        } else {
            println!("[java] {} protocol {} -> 1.16 chunk slicer", peer, protocol);
        }
    }
    Ok(())
}

fn read_varint(buf: &[u8], pos: &mut usize) -> Option<i32> {
    let mut result: i32 = 0;
    for i in 0..5 {
        let byte = *buf.get(*pos)?;
        *pos += 1;
        result |= ((byte & 0x7F) as i32) << (7 * i);
        if byte & 0x80 == 0 {
            return Some(result);
        }
    }
    None
}

async fn run_bedrock_udp() -> Result<()> {
    let socket = Arc::new(UdpSocket::bind(("0.0.0.0", BEDROCK_UDP_PORT)).await?);
    let mut buf = [0u8; 2048];
    loop {
        let (len, peer) = socket.recv_from(&mut buf).await?;
        if len == 0 {
            continue;
        }
        if buf[0] == 0x01 && len >= 9 {
            let mut time_bytes = [0u8; 8];
            time_bytes.copy_from_slice(&buf[1..9]);
            let ping_time = u64::from_be_bytes(time_bytes);
            let pong = build_raknet_pong(ping_time, SERVER_GUID);
            socket.send_to(&pong, peer).await?;
            println!("[bedrock] pong -> {}", peer);
        }
    }
}

fn build_raknet_pong(ping_time: u64, guid: u64) -> Vec<u8> {
    let motd = "MCPE;TrinityMax Core;594;1.20.40;0;20;1337;Trinity Level;Survival;";
    let mut pong = Vec::with_capacity(40 + motd.len());
    pong.push(0x1c);
    pong.extend_from_slice(&ping_time.to_be_bytes());
    pong.extend_from_slice(&RAKNET_MAGIC);
    pong.extend_from_slice(&guid.to_be_bytes());
    pong.extend_from_slice(&(motd.len() as u16).to_be_bytes());
    pong.extend_from_slice(motd.as_bytes());
    pong
}

async fn run_tunnel_client() -> Result<()> {
    loop {
        println!("[tunnel] heartbeat (stub)");
        sleep(Duration::from_secs(30)).await;
    }
}
eep(Duration::from_secs(30)).await;
    }
}
