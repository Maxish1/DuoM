use std::collections::{HashMap, HashSet};
use std::fs;
use std::net::SocketAddr;
use std::os::raw::c_void;
use std::path::Path;
use std::sync::{Arc, OnceLock};
use std::time::Duration;

use anyhow::Result;
use rhai::{AST, Engine, Scope};
use serde::Deserialize;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::{TcpListener, TcpStream, UdpSocket};
use tokio::time::sleep;

const DEFAULT_SERVER_NAME: &str = "IshCraft";
const DEFAULT_JAVA_TCP_PORT: u16 = 25565;
const DEFAULT_BEDROCK_UDP_PORT: u16 = 19132;
const SERVER_GUID: u64 = 0x54524E4954594D58;

const RAKNET_MAGIC: [u8; 16] = [
    0x00, 0xff, 0xff, 0x00, 0xfe, 0xfe, 0xfe, 0xfe,
    0xfd, 0xfd, 0xfd, 0xfd, 0x12, 0x34, 0x56, 0x78,
];

static DATA_DIR: OnceLock<String> = OnceLock::new();

#[derive(Deserialize, Default)]
struct WhitelistFile {
    players: Vec<String>,
}

#[derive(Clone)]
struct ServerConfig {
    props: HashMap<String, String>,
}

impl ServerConfig {
    fn load(base_dir: &str) -> Self {
        let _ = fs::create_dir_all(base_dir);
        let path = Path::new(base_dir).join("server.properties");
        let mut props = HashMap::new();

        props.insert("server-name".to_string(), DEFAULT_SERVER_NAME.to_string());
        props.insert(
            "motd".to_string(),
            "§6§lIshCraft §8» §fSeason 1 §7[Java & Bedrock]".to_string(),
        );
        props.insert(
            "bedrock-line1".to_string(),
            "§l§6IshCraft §r§7| §eHermit-Style SMP".to_string(),
        );
        props.insert(
            "bedrock-line2".to_string(),
            "§aJava 1.7-1.26 • Bedrock 1.16-26".to_string(),
        );
        props.insert("java-port".to_string(), DEFAULT_JAVA_TCP_PORT.to_string());
        props.insert("bedrock-port".to_string(), DEFAULT_BEDROCK_UDP_PORT.to_string());
        props.insert("max-players".to_string(), "20".to_string());
        props.insert("whitelist-enabled".to_string(), "true".to_string());
        props.insert("one-player-sleep".to_string(), "true".to_string());

        if let Ok(content) = fs::read_to_string(&path) {
            for line in content.lines() {
                let trimmed = line.trim();
                if trimmed.is_empty() || trimmed.starts_with('#') || trimmed.starts_with('!') {
                    continue;
                }
                if let Some((k, v)) = trimmed.split_once('=') {
                    props.insert(k.trim().to_string(), v.trim().to_string());
                }
            }
            println!("[{}] loaded server.properties from {:?}", Self::default_name(&props), path);
        } else {
            let default_props = "server-name=IshCraft
motd=§6§lIshCraft §8» §fSeason 1 §7[Java & Bedrock]
bedrock-line1=§l§6IshCraft §r§7| §eHermit-Style SMP
bedrock-line2=§aJava 1.7-1.26 • Bedrock 1.16-26
java-port=25565
bedrock-port=19132
max-players=20
whitelist-enabled=true
one-player-sleep=true
";
            let _ = fs::write(&path, default_props);
            println!("[{}] created default server.properties at {:?}", DEFAULT_SERVER_NAME, path);
        }

        Self { props }
    }

    fn default_name(props: &HashMap<String, String>) -> &str {
        props
            .get("server-name")
            .map(|s| s.as_str())
            .unwrap_or(DEFAULT_SERVER_NAME)
    }

    fn server_name(&self) -> &str {
        Self::default_name(&self.props)
    }

    fn motd(&self) -> &str {
        self.props
            .get("motd")
            .map(|s| s.as_str())
            .unwrap_or("§6§lIshCraft §8» §fSeason 1")
    }

    fn bedrock_line1(&self) -> &str {
        self.props
            .get("bedrock-line1")
            .map(|s| s.as_str())
            .unwrap_or("§l§6IshCraft §r§7| §eSMP")
    }

    fn bedrock_line2(&self) -> &str {
        self.props
            .get("bedrock-line2")
            .map(|s| s.as_str())
            .unwrap_or("§aCross-Play")
    }

    fn java_port(&self) -> u16 {
        self.props
            .get("java-port")
            .and_then(|v| v.parse().ok())
            .unwrap_or(DEFAULT_JAVA_TCP_PORT)
    }

    fn bedrock_port(&self) -> u16 {
        self.props
            .get("bedrock-port")
            .and_then(|v| v.parse().ok())
            .unwrap_or(DEFAULT_BEDROCK_UDP_PORT)
    }

    fn max_players(&self) -> i32 {
        self.props
            .get("max-players")
            .and_then(|v| v.parse().ok())
            .unwrap_or(20)
    }

    fn whitelist_enabled(&self) -> bool {
        self.props
            .get("whitelist-enabled")
            .map(|v| v.eq_ignore_ascii_case("true") || v == "1")
            .unwrap_or(true)
    }
}

struct ServerState {
    config: ServerConfig,
    whitelist: HashSet<String>,
    plugins: Vec<(String, AST)>,
    engine: Engine,
}

impl ServerState {
    fn load(base_dir: &str) -> Self {
        let config = ServerConfig::load(base_dir);
        let whitelist = Self::load_whitelist(base_dir, config.server_name());
        let mut engine = Engine::new();

        let srv_name = config.server_name().to_string();
        engine.register_fn("log_info", move |msg: &str| {
            println!("[{}][plugin] {}", srv_name, msg);
        });

        let plugins = Self::load_plugins(&engine, base_dir, config.server_name());

        Self {
            config,
            whitelist,
            plugins,
            engine,
        }
    }

    fn load_whitelist(base_dir: &str, server_name: &str) -> HashSet<String> {
        let _ = fs::create_dir_all(base_dir);
        let path = Path::new(base_dir).join("whitelist.json");
        if let Ok(raw) = fs::read_to_string(&path) {
            if let Ok(parsed) = serde_json::from_str::<WhitelistFile>(&raw) {
                println!(
                    "[{}] loaded {} whitelisted players from {:?}",
                    server_name,
                    parsed.players.len(),
                    path
                );
                return parsed
                    .players
                    .into_iter()
                    .map(|p| p.trim().to_lowercase())
                    .collect();
            }
        } else {
            let default_json = "{
  "players": [
    "Maxish1"
  ]
}
";
            let _ = fs::write(&path, default_json);
            println!("[{}] created default whitelist.json at {:?}", server_name, path);
        }

        let mut fallback = HashSet::new();
        fallback.insert("maxish1".to_string());
        fallback
    }

    fn load_plugins(engine: &Engine, base_dir: &str, server_name: &str) -> Vec<(String, AST)> {
        let plugin_dir = Path::new(base_dir).join("plugins");
        let _ = fs::create_dir_all(&plugin_dir);
        let mut loaded = Vec::new();

        if let Ok(entries) = fs::read_dir(&plugin_dir) {
            for entry in entries.flatten() {
                let path = entry.path();
                if path.extension().and_then(|s| s.to_str()) == Some("rhai") {
                    let name = path
                        .file_name()
                        .unwrap_or_default()
                        .to_string_lossy()
                        .to_string();
                    match engine.compile_file(path) {
                        Ok(ast) => {
                            println!("[{}] loaded plugin: {}", server_name, name);
                            loaded.push((name, ast));
                        }
                        Err(err) => {
                            eprintln!("[{}] failed to compile plugin {}: {}", server_name, name, err);
                        }
                    }
                }
            }
        }
        loaded
    }

    fn is_whitelisted(&self, username: &str) -> bool {
        if !self.config.whitelist_enabled() {
            return true;
        }
        self.whitelist.contains(&username.trim().to_lowercase())
    }

    fn fire_event(&self, fn_name: &str, arg: &str) {
        for (name, ast) in &self.plugins {
            let mut scope = Scope::new();
            if let Err(err) = self
                .engine
                .call_fn::<()>(&mut scope, ast, fn_name, (arg.to_string(),))
            {
                let msg = err.to_string();
                if !msg.contains("Function not found") {
                    eprintln!(
                        "[{}][{}] hook {} error: {}",
                        self.config.server_name(),
                        name,
                        fn_name,
                        msg
                    );
                }
            }
        }
    }
}

/// Maps Java protocol versions across 1.7.x (protocol 4..5) through 1.26.x
fn java_protocol_label(protocol: i32) -> &'static str {
    match protocol {
        4..=5 => "1.7.x",
        47 => "1.8.x",
        107..=110 => "1.9.x",
        210 => "1.10.x",
        315..=316 => "1.11.x",
        335..=340 => "1.12.x",
        393..=404 => "1.13.x",
        477..=498 => "1.14.x",
        573..=578 => "1.15.x",
        735..=754 => "1.16.x",
        755..=756 => "1.17.x",
        757..=758 => "1.18.x",
        759..=760 => "1.19.x",
        763..=764 => "1.20.x",
        765..=767 => "1.20.5-1.21.1",
        768..=770 => "1.21.2-1.21.5",
        771..=799 => "1.21.6-1.25.x",
        800..=1000 => "1.26.x",
        _ => "Java 1.7-1.26+",
    }
}

fn is_supported_java_protocol(protocol: i32) -> bool {
    (4..=5).contains(&protocol) || (47..=1000).contains(&protocol)
}

/// Maps Bedrock RakNet/MCPE protocol versions across 1.16.x through 26.x
fn bedrock_protocol_label(protocol: i32) -> &'static str {
    match protocol {
        407..=419 => "1.16.x",
        422..=448 => "1.17.x",
        465..=486 => "1.18.x",
        503..=554 => "1.19.x",
        560..=618 => "1.20.x",
        622..=729 => "1.21.x",
        730..=999 => "1.22-25.x",
        1000..=1500 => "26.x",
        _ => "Bedrock 1.16-26+",
    }
}

fn is_supported_bedrock_protocol(protocol: i32) -> bool {
    (407..=1500).contains(&protocol)
}

fn requires_1_18_plus_crypto(protocol_version: i32) -> bool {
    protocol_version >= 757
}

pub fn set_data_dir(dir: String) {
    let _ = DATA_DIR.set(dir);
}

pub fn start_server_internal() {
    let data_dir = DATA_DIR
        .get()
        .cloned()
        .unwrap_or_else(|| ".".to_string());

    std::thread::spawn(move || {
        let rt = tokio::runtime::Runtime::new().unwrap();
        rt.block_on(async move {
            if let Err(e) = run_server(data_dir).await {
                eprintln!("[trinitymax] fatal server error: {}", e);
            }
        });
    });
}

#[no_mangle]
pub extern "C" fn Java_com_trinitymax_server_RustBridge_startServer(
    _env: *mut c_void,
    _this: *mut c_void,
) {
    set_data_dir("/data/data/com.trinitymax.server/files".to_string());
    start_server_internal();
}

async fn run_server(data_dir: String) -> Result<()> {
    let state = Arc::new(ServerState::load(&data_dir));
    let java_port = state.config.java_port();
    let bedrock_port = state.config.bedrock_port();

    println!(
        "[trinitymax] booting {} cross-play server core...",
        state.config.server_name()
    );
    println!("[trinitymax] java tcp    on :{} (1.7.x - 1.26.x)", java_port);
    println!("[trinitymax] bedrock udp on :{} (1.16.x - 26.x)", bedrock_port);

    state.fire_event("on_server_start", state.config.server_name());

    let tcp_state = Arc::clone(&state);
    let udp_state = Arc::clone(&state);

    let tcp = tokio::spawn(run_java_tcp(java_port, tcp_state));
    let udp = tokio::spawn(run_bedrock_udp(bedrock_port, udp_state));
    let tunnel = tokio::spawn(run_tunnel_client());

    tcp.await??;
    udp.await??;
    tunnel.await??;
    Ok(())
}

async fn run_java_tcp(port: u16, state: Arc<ServerState>) -> Result<()> {
    let listener = TcpListener::bind(("0.0.0.0", port)).await?;
    loop {
        let (socket, peer) = listener.accept().await?;
        let conn_state = Arc::clone(&state);
        tokio::spawn(handle_java_connection(socket, peer, conn_state));
    }
}

async fn handle_java_connection(
    mut socket: TcpStream,
    peer: SocketAddr,
    state: Arc<ServerState>,
) -> Result<()> {
    socket.set_nodelay(true)?;
    let mut buf = [0u8; 512];
    let n = socket.read(&mut buf).await?;
    if n == 0 {
        return Ok(());
    }

    let mut pos = 0usize;
    let _packet_len = match read_varint(&buf[..n], &mut pos) {
        Some(v) => v,
        None => return Ok(()),
    };
    let packet_id = match read_varint(&buf[..n], &mut pos) {
        Some(v) => v,
        None => return Ok(()),
    };

    if packet_id == 0x00 {
        let protocol = match read_varint(&buf[..n], &mut pos) {
            Some(v) => v,
            None => return Ok(()),
        };
        let _server_addr = read_mc_string(&buf[..n], &mut pos);
        if pos + 2 <= n {
            pos += 2;
        }
        let next_state = read_varint(&buf[..n], &mut pos).unwrap_or(1);
        let ver_label = java_protocol_label(protocol);

        if next_state == 1 {
            let status_version_name = if is_supported_java_protocol(protocol) {
                ver_label
            } else {
                "1.7.x-1.26.x"
            };
            let status_json = format!(
                r#"{{"version":{{"name":"{}","protocol":{}}},"players":{{"max":{},"online":0}},"description":{{"text":"{}"}}}}"#,
                status_version_name,
                protocol,
                state.config.max_players(),
                state.config.motd().replace('
', "\n")
            );
            let resp = build_java_string_packet(0x00, &status_json);
            socket.write_all(&resp).await?;
            socket.flush().await?;
            state.fire_event("on_java_ping", &peer.to_string());
        } else if next_state == 2 {
            let mut username = String::new();
            if pos < n {
                let _login_len = read_varint(&buf[..n], &mut pos);
                if read_varint(&buf[..n], &mut pos) == Some(0x00) {
                    username = read_mc_string(&buf[..n], &mut pos).unwrap_or_default();
                }
            } else if let Ok(m) = socket.read(&mut buf).await {
                if m > 0 {
                    let mut lpos = 0;
                    let _login_len = read_varint(&buf[..m], &mut lpos);
                    if read_varint(&buf[..m], &mut lpos) == Some(0x00) {
                        username = read_mc_string(&buf[..m], &mut lpos).unwrap_or_default();
                    }
                }
            }

            if !is_supported_java_protocol(protocol) {
                let kick = format!(
                    r#"{{"text":"§cUnsupported Java version (protocol {}). Supported: 1.7.x - 1.26.x"}}"#,
                    protocol
                );
                let pkt = build_java_string_packet(0x00, &kick);
                socket.write_all(&pkt).await?;
                socket.flush().await?;
                return Ok(());
            }

            if !username.is_empty() && !state.is_whitelisted(&username) {
                println!(
                    "[java] {} rejected non-whitelisted player '{}'",
                    peer, username
                );
                state.fire_event("on_login_denied", &username);
                let kick = format!(
                    r#"{{"text":"§cYou are not whitelisted on {}!"}}"#,
                    state.config.server_name()
                );
                let pkt = build_java_string_packet(0x00, &kick);
                socket.write_all(&pkt).await?;
                socket.flush().await?;
                return Ok(());
            }

            if requires_1_18_plus_crypto(protocol) {
                println!(
                    "[java] {} ({}) {} [proto {}] -> 1.18+ crypto path",
                    peer, username, ver_label, protocol
                );
            } else {
                println!(
                    "[java] {} ({}) {} [proto {}] -> legacy/1.16 chunk slicer",
                    peer, username, ver_label, protocol
                );
            }
        }
    }
    Ok(())
}

fn read_varint(buf: &[u8], pos: &mut usize) -> Option<i32> {
    let mut result: i32 = 0;
    for i in 0..5 {
        let byte = *buf.get(*pos)?;
        *pos += 1;
        result |= ((byte & 0x7F) as i32) << (7 * i);
        if byte & 0x80 == 0 {
            return Some(result);
        }
    }
    None
}

fn read_mc_string(buf: &[u8], pos: &mut usize) -> Option<String> {
    let len = read_varint(buf, pos)? as usize;
    if *pos + len > buf.len() {
        return None;
    }
    let s = String::from_utf8_lossy(&buf[*pos..*pos + len]).to_string();
    *pos += len;
    Some(s)
}

fn write_varint(buf: &mut Vec<u8>, mut value: i32) {
    loop {
        if (value & !0x7F) == 0 {
            buf.push(value as u8);
            return;
        }
        buf.push(((value & 0x7F) | 0x80) as u8);
        value = ((value as u32) >> 7) as i32;
    }
}

fn build_java_string_packet(packet_id: u8, payload: &str) -> Vec<u8> {
    let mut inner = Vec::new();
    write_varint(&mut inner, packet_id as i32);
    write_varint(&mut inner, payload.len() as i32);
    inner.extend_from_slice(payload.as_bytes());

    let mut full = Vec::new();
    write_varint(&mut full, inner.len() as i32);
    full.extend_from_slice(&inner);
    full
}

async fn run_bedrock_udp(port: u16, state: Arc<ServerState>) -> Result<()> {
    let socket = Arc::new(UdpSocket::bind(("0.0.0.0", port)).await?);
    let mut buf = [0u8; 2048];
    loop {
        let (len, peer) = socket.recv_from(&mut buf).await?;
        if len == 0 {
            continue;
        }
        if (buf[0] == 0x01 || buf[0] == 0x02) && len >= 9 {
            let mut time_bytes = [0u8; 8];
            time_bytes.copy_from_slice(&buf[1..9]);
            let ping_time = u64::from_be_bytes(time_bytes);
            let pong = build_raknet_pong(ping_time, SERVER_GUID, &state.config, port);
            socket.send_to(&pong, peer).await?;
            println!("[bedrock] pong -> {} (1.16.x - 26.x)", peer);
            state.fire_event("on_bedrock_ping", &peer.to_string());
        }
    }
}

fn build_raknet_pong(ping_time: u64, guid: u64, cfg: &ServerConfig, port: u16) -> Vec<u8> {
    let motd = format!(
        "MCPE;{};766;1.21.50;0;{};{};{};Survival;1;{};{};",
        cfg.bedrock_line1(),
        cfg.max_players(),
        guid,
        cfg.bedrock_line2(),
        port,
        port + 1
    );
    let mut pong = Vec::with_capacity(40 + motd.len());
    pong.push(0x1c);
    pong.extend_from_slice(&ping_time.to_be_bytes());
    pong.extend_from_slice(&RAKNET_MAGIC);
    pong.extend_from_slice(&guid.to_be_bytes());
    pong.extend_from_slice(&(motd.len() as u16).to_be_bytes());
    pong.extend_from_slice(motd.as_bytes());
    pong
}

async fn run_tunnel_client() -> Result<()> {
    loop {
        println!("[tunnel] heartbeat (stub)");
        sleep(Duration::from_secs(30)).await;
    }
}
