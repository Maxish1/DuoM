use std::collections::{HashMap, HashSet};
use std::fs;
use std::net::SocketAddr;
use std::os::raw::c_void;
use std::path::Path;
use std::sync::{Arc, OnceLock};
use std::time::Duration;

use anyhow::Result;
use rhai::{AST, Engine, Scope};
use serde::Deserialize;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::{TcpListener, TcpStream, UdpSocket};
use tokio::sync::RwLock;
use tokio::time::sleep;

const DEFAULT_SERVER_NAME: &str = "DuoM";
const DEFAULT_BIND_IP: &str = "0.0.0.0";
const DEFAULT_JAVA_TCP_PORT: u16 = 25565;
const DEFAULT_BEDROCK_UDP_PORT: u16 = 19132;
const SERVER_GUID: u64 = 0x54524E4954594D58;

const RAKNET_MAGIC: [u8; 16] = [
    0x00, 0xff, 0xff, 0x00, 0xfe, 0xfe, 0xfe, 0xfe,
    0xfd, 0xfd, 0xfd, 0xfd, 0x12, 0x34, 0x56, 0x78,
];

const DEFAULT_PROPERTIES_CONTENT: &str = "\
# DuoM Server Configuration (TrinityMax Core)
server-name=DuoM
motd=§6§lDuoM §8» §fSeason 1 §7[Java • Bedrock • PE]
bedrock-line1=§l§6DuoM §r§7| §eCross-Play SMP
bedrock-line2=§aJava • Bedrock • PE 0.15+

# Network & Ports
server-ip=0.0.0.0
java-port=25565
bedrock-port=19132
bedrock-port-v6=19133
network-compression-threshold=256
enable-status=true

# Players & Security
max-players=20
white-list=true
whitelist-enabled=true
enforce-whitelist=true
online-mode=false
xbox-auth=false

# Gameplay & World
level-name=world
level-seed=1337
level-type=flat
gamemode=survival
force-gamemode=false
difficulty=hard
hardcore=false
pvp=true
allow-flight=false
allow-nether=true
allow-end=true
spawn-protection=16
spawn-monsters=true
spawn-animals=true
spawn-npcs=true
one-player-sleep=true

# Performance (Optimized for Android / Low-RAM Hosts)
view-distance=6
simulation-distance=4
max-tick-time=60000
entity-broadcast-range-percentage=100
sync-chunk-writes=false

# Plugins & Tunnel
enable-plugins=true
plugins-dir=plugins
enable-tunnel=false
tunnel-token=
";

static DATA_DIR: OnceLock<String> = OnceLock::new();

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
enum ClientPlatform {
    Java,
    Bedrock,
    PocketEdition,
}

impl ClientPlatform {
    fn as_str(self) -> &'static str {
        match self {
            ClientPlatform::Java => "Java",
            ClientPlatform::Bedrock => "Bedrock",
            ClientPlatform::PocketEdition => "PE",
        }
    }
}

#[derive(Debug, Clone)]
struct PlayerSession {
    name: String,
    platform: ClientPlatform,
    protocol: i32,
    addr: String,
    x: f64,
    y: f64,
    z: f64,
}

#[derive(Debug, Clone)]
struct ChunkData {
    cx: i32,
    cz: i32,
    /// Block palette / surface height map (16x16) for low-RAM world hosting
    surface_y: [u8; 256],
    top_block: &'static str,
    biome: &'static str,
}

impl ChunkData {
    fn generate(cx: i32, cz: i32, seed: i64, level_type: &str) -> Self {
        let mut surface_y = [64u8; 256];
        let is_flat = level_type.eq_ignore_ascii_case("flat") || level_type.contains("flat");
        for idx in 0..256 {
            let lx = (idx & 15) as i64;
            let lz = (idx >> 4) as i64;
            let wx = (cx as i64) * 16 + lx;
            let wz = (cz as i64) * 16 + lz;
            if is_flat {
                surface_y[idx] = 4;
            } else {
                let wave = ((wx.wrapping_mul(31) ^ wz.wrapping_mul(17) ^ seed).abs() % 7) as u8;
                surface_y[idx] = 62 + wave;
            }
        }
        Self {
            cx,
            cz,
            surface_y,
            top_block: if is_flat { "minecraft:grass_block" } else { "minecraft:grass_block" },
            biome: "minecraft:plains",
        }
    }
}

struct WorldManager {
    level_name: String,
    seed: i64,
    level_type: String,
    spawn_x: f64,
    spawn_y: f64,
    spawn_z: f64,
    chunks: HashMap<(i32, i32), ChunkData>,
    blocks: HashMap<(i32, i32, i32), String>,
    players: HashMap<String, PlayerSession>,
}

impl WorldManager {
    fn new(level_name: String, seed: i64, level_type: String) -> Self {
        let spawn_y = if level_type.eq_ignore_ascii_case("flat") {
            5.0
        } else {
            66.0
        };
        Self {
            level_name,
            seed,
            level_type,
            spawn_x: 0.5,
            spawn_y,
            spawn_z: 0.5,
            chunks: HashMap::new(),
            blocks: HashMap::new(),
            players: HashMap::new(),
        }
    }

    fn get_or_generate_chunk(&mut self, cx: i32, cz: i32) -> ChunkData {
        if let Some(existing) = self.chunks.get(&(cx, cz)) {
            return existing.clone();
        }
        let generated = ChunkData::generate(cx, cz, self.seed, &self.level_type);
        // Bounded low-RAM cache on Android hosts
        if self.chunks.len() >= 1024 {
            if let Some(&oldest_key) = self.chunks.keys().next() {
                self.chunks.remove(&oldest_key);
            }
        }
        self.chunks.insert((cx, cz), generated.clone());
        generated
    }

    fn set_block(&mut self, x: i32, y: i32, z: i32, block_id: String) {
        if block_id == "air" || block_id == "minecraft:air" {
            self.blocks.remove(&(x, y, z));
        } else {
            self.blocks.insert((x, y, z), block_id);
        }
    }

    fn join_player(&mut self, name: String, platform: ClientPlatform, protocol: i32, addr: String) -> PlayerSession {
        let session = PlayerSession {
            name: name.clone(),
            platform,
            protocol,
            addr,
            x: self.spawn_x,
            y: self.spawn_y,
            z: self.spawn_z,
        };
        self.players.insert(name.to_lowercase(), session.clone());
        session
    }

    fn update_player_pos(&mut self, name: &str, x: f64, y: f64, z: f64) {
        if let Some(p) = self.players.get_mut(&name.to_lowercase()) {
            p.x = x;
            p.y = y;
            p.z = z;
        }
    }

    fn remove_player(&mut self, name: &str) {
        self.players.remove(&name.to_lowercase());
    }

    fn online_count(&self) -> usize {
        self.players.len()
    }
}

#[derive(Deserialize, Default)]
struct WhitelistFile {
    players: Vec<String>,
}

#[derive(Clone)]
struct ServerConfig {
    props: HashMap<String, String>,
}

impl ServerConfig {
    fn load(base_dir: &str) -> Self {
        let _ = fs::create_dir_all(base_dir);
        let path = Path::new(base_dir).join("server.properties");
        let mut props = HashMap::new();

        for line in DEFAULT_PROPERTIES_CONTENT.lines() {
            let trimmed = line.trim();
            if trimmed.is_empty() || trimmed.starts_with('#') || trimmed.starts_with('!') {
                continue;
            }
            if let Some((k, v)) = trimmed.split_once('=') {
                props.insert(k.trim().to_string(), v.trim().to_string());
            }
        }

        if let Ok(content) = fs::read_to_string(&path) {
            for line in content.lines() {
                let trimmed = line.trim();
                if trimmed.is_empty() || trimmed.starts_with('#') || trimmed.starts_with('!') {
                    continue;
                }
                if let Some((k, v)) = trimmed.split_once('=') {
                    props.insert(k.trim().to_string(), v.trim().to_string());
                }
            }
            println!("[{}] loaded server.properties from {:?}", Self::default_name(&props), path);
        } else {
            let _ = fs::write(&path, DEFAULT_PROPERTIES_CONTENT);
            println!("[{}] created default server.properties at {:?}", DEFAULT_SERVER_NAME, path);
        }

        Self { props }
    }

    fn get_str<'a>(&'a self, key: &str, default: &'a str) -> &'a str {
        self.props.get(key).map(|s| s.as_str()).unwrap_or(default)
    }

    fn get_bool(&self, key: &str, default: bool) -> bool {
        self.props
            .get(key)
            .map(|v| v.eq_ignore_ascii_case("true") || v == "1" || v.eq_ignore_ascii_case("yes"))
            .unwrap_or(default)
    }

    fn get_u16(&self, key: &str, default: u16) -> u16 {
        self.props
            .get(key)
            .and_then(|v| v.parse().ok())
            .unwrap_or(default)
    }

    fn get_i32(&self, key: &str, default: i32) -> i32 {
        self.props
            .get(key)
            .and_then(|v| v.parse().ok())
            .unwrap_or(default)
    }

    fn get_i64(&self, key: &str, default: i64) -> i64 {
        self.props
            .get(key)
            .and_then(|v| v.parse().ok())
            .unwrap_or(default)
    }

    fn default_name(props: &HashMap<String, String>) -> &str {
        props
            .get("server-name")
            .map(|s| s.as_str())
            .unwrap_or(DEFAULT_SERVER_NAME)
    }

    fn server_name(&self) -> &str {
        Self::default_name(&self.props)
    }

    fn server_ip(&self) -> &str {
        self.get_str("server-ip", DEFAULT_BIND_IP)
    }

    fn motd(&self) -> &str {
        self.get_str("motd", "§6§lDuoM §8» §fSeason 1")
    }

    fn bedrock_line1(&self) -> &str {
        self.get_str("bedrock-line1", "§l§6DuoM §r§7| §eCross-Play SMP")
    }

    fn bedrock_line2(&self) -> &str {
        self.get_str("bedrock-line2", "§aCross-Play")
    }

    fn java_port(&self) -> u16 {
        self.get_u16("java-port", DEFAULT_JAVA_TCP_PORT)
    }

    fn bedrock_port(&self) -> u16 {
        self.get_u16("bedrock-port", DEFAULT_BEDROCK_UDP_PORT)
    }

    fn bedrock_port_v6(&self) -> u16 {
        self.get_u16("bedrock-port-v6", self.bedrock_port() + 1)
    }

    fn enable_status(&self) -> bool {
        self.get_bool("enable-status", true)
    }

    fn max_players(&self) -> i32 {
        self.get_i32("max-players", 20)
    }

    fn whitelist_enabled(&self) -> bool {
        self.get_bool("whitelist-enabled", self.get_bool("white-list", true))
    }

    fn gamemode_label(&self) -> &'static str {
        match self.get_str("gamemode", "survival").to_ascii_lowercase().as_str() {
            "creative" | "1" => "Creative",
            "adventure" | "2" => "Adventure",
            "spectator" | "3" => "Spectator",
            _ => "Survival",
        }
    }

    fn view_distance(&self) -> i32 {
        self.get_i32("view-distance", 6).clamp(2, 32)
    }

    fn simulation_distance(&self) -> i32 {
        self.get_i32("simulation-distance", 4).clamp(2, 32)
    }

    fn enable_plugins(&self) -> bool {
        self.get_bool("enable-plugins", true)
    }

    fn plugins_dir(&self) -> &str {
        self.get_str("plugins-dir", "plugins")
    }

    fn enable_tunnel(&self) -> bool {
        self.get_bool("enable-tunnel", false)
    }
}

struct ServerState {
    config: ServerConfig,
    whitelist: HashSet<String>,
    plugins: Vec<(String, AST)>,
    engine: Engine,
    world: RwLock<WorldManager>,
}

impl ServerState {
    fn load(base_dir: &str) -> Self {
        let config = ServerConfig::load(base_dir);
        let whitelist = Self::load_whitelist(base_dir, config.server_name());
        let mut engine = Engine::new();

        let srv_name = config.server_name().to_string();
        engine.register_fn("log_info", move |msg: &str| {
            println!("[{}][plugin] {}", srv_name, msg);
        });

        let plugins = if config.enable_plugins() {
            Self::load_plugins(&engine, base_dir, config.plugins_dir(), config.server_name())
        } else {
            println!("[{}] plugins disabled in server.properties", config.server_name());
            Vec::new()
        };

        let level_name = config.get_str("level-name", "world").to_string();
        let seed = config.get_i64("level-seed", 1337);
        let level_type = config.get_str("level-type", "flat").to_string();
        let world = RwLock::new(WorldManager::new(level_name, seed, level_type));

        Self {
            config,
            whitelist,
            plugins,
            engine,
            world,
        }
    }

    fn load_whitelist(base_dir: &str, server_name: &str) -> HashSet<String> {
        let _ = fs::create_dir_all(base_dir);
        let path = Path::new(base_dir).join("whitelist.json");
        if let Ok(raw) = fs::read_to_string(&path) {
            if let Ok(parsed) = serde_json::from_str::<WhitelistFile>(&raw) {
                println!(
                    "[{}] loaded {} whitelisted players from {:?}",
                    server_name,
                    parsed.players.len(),
                    path
                );
                return parsed
                    .players
                    .into_iter()
                    .map(|p| p.trim().to_lowercase())
                    .collect();
            }
        } else {
            let default_json = "{\n  \"players\": [\n    \"Maxish1\"\n  ]\n}\n";
            let _ = fs::write(&path, default_json);
            println!("[{}] created default whitelist.json at {:?}", server_name, path);
        }

        let mut fallback = HashSet::new();
        fallback.insert("maxish1".to_string());
        fallback
    }

    fn load_plugins(
        engine: &Engine,
        base_dir: &str,
        rel_plugins_dir: &str,
        server_name: &str,
    ) -> Vec<(String, AST)> {
        let plugin_dir = Path::new(base_dir).join(rel_plugins_dir);
        let _ = fs::create_dir_all(&plugin_dir);
        let mut loaded = Vec::new();

        if let Ok(entries) = fs::read_dir(&plugin_dir) {
            for entry in entries.flatten() {
                let path = entry.path();
                if path.extension().and_then(|s| s.to_str()) == Some("rhai") {
                    let name = path
                        .file_name()
                        .unwrap_or_default()
                        .to_string_lossy()
                        .to_string();
                    match engine.compile_file(path) {
                        Ok(ast) => {
                            println!("[{}] loaded plugin: {}", server_name, name);
                            loaded.push((name, ast));
                        }
                        Err(err) => {
                            eprintln!("[{}] failed to compile plugin {}: {}", server_name, name, err);
                        }
                    }
                }
            }
        }
        loaded
    }

    fn is_whitelisted(&self, username: &str) -> bool {
        if !self.config.whitelist_enabled() {
            return true;
        }
        self.whitelist.contains(&username.trim().to_lowercase())
    }

    fn fire_event(&self, fn_name: &str, arg: &str) {
        for (name, ast) in &self.plugins {
            let mut scope = Scope::new();
            if let Err(err) = self
                .engine
                .call_fn::<()>(&mut scope, ast, fn_name, (arg.to_string(),))
            {
                let msg = err.to_string();
                if !msg.contains("Function not found") {
                    eprintln!(
                        "[{}][{}] hook {} error: {}",
                        self.config.server_name(),
                        name,
                        fn_name,
                        msg
                    );
                }
            }
        }
    }
}

/// Maps Java protocol versions across 1.7.x (protocol 4..5) through 1.26.x
fn java_protocol_label(protocol: i32) -> &'static str {
    match protocol {
        4..=5 => "1.7.x",
        47 => "1.8.x",
        107..=110 => "1.9.x",
        210 => "1.10.x",
        315..=316 => "1.11.x",
        335..=340 => "1.12.x",
        393..=404 => "1.13.x",
        477..=498 => "1.14.x",
        573..=578 => "1.15.x",
        735..=754 => "1.16.x",
        755..=756 => "1.17.x",
        757..=758 => "1.18.x",
        759..=760 => "1.19.x",
        763..=764 => "1.20.x",
        765..=767 => "1.20.5-1.21.1",
        768..=770 => "1.21.2-1.21.5",
        771..=799 => "1.21.6-1.25.x",
        800..=1000 => "1.26.x",
        _ => "Java 1.7-1.26+",
    }
}

fn is_supported_java_protocol(protocol: i32) -> bool {
    (4..=5).contains(&protocol) || (47..=1000).contains(&protocol)
}

/// Maps Bedrock & Pocket Edition (PE) RakNet/MCPE protocol versions
fn bedrock_protocol_label(protocol: i32) -> &'static str {
    match protocol {
        81..=93 => "PE 0.15.x",
        100..=160 => "PE/Bedrock 1.0-1.2",
        274..=390 => "Bedrock 1.7-1.14",
        407..=419 => "Bedrock 1.16.x",
        422..=448 => "Bedrock 1.17.x",
        465..=486 => "Bedrock 1.18.x",
        503..=554 => "Bedrock 1.19.x",
        560..=618 => "Bedrock 1.20.x",
        622..=729 => "Bedrock 1.21.x",
        730..=999 => "Bedrock 1.22-25.x",
        1000..=1500 => "Bedrock 26.x",
        _ => "Bedrock/PE",
    }
}

fn classify_bedrock_platform(protocol: i32) -> ClientPlatform {
    if protocol <= 137 {
        ClientPlatform::PocketEdition
    } else {
        ClientPlatform::Bedrock
    }
}

fn requires_1_18_plus_crypto(protocol_version: i32) -> bool {
    protocol_version >= 757
}

pub fn set_data_dir(dir: String) {
    let _ = DATA_DIR.set(dir);
}

pub fn start_server_internal() {
    let data_dir = DATA_DIR
        .get()
        .cloned()
        .unwrap_or_else(|| ".".to_string());

    std::thread::spawn(move || {
        let rt = tokio::runtime::Runtime::new().unwrap();
        rt.block_on(async move {
            if let Err(e) = run_server(data_dir).await {
                eprintln!("[trinitymax] fatal server error: {}", e);
            }
        });
    });
}

#[no_mangle]
pub extern "C" fn Java_com_trinitymax_server_RustBridge_startServer(
    _env: *mut c_void,
    _this: *mut c_void,
) {
    set_data_dir("/data/data/com.trinitymax.server/files".to_string());
    start_server_internal();
}

async fn run_server(data_dir: String) -> Result<()> {
    let state = Arc::new(ServerState::load(&data_dir));
    let bind_ip = state.config.server_ip().to_string();
    let java_port = state.config.java_port();
    let bedrock_port = state.config.bedrock_port();

    {
        let mut w = state.world.write().await;
        for cx in -1..=1 {
            for cz in -1..=1 {
                let _ = w.get_or_generate_chunk(cx, cz);
            }
        }
        println!(
            "[world] hosted '{}' (type={}, seed={}) with {} pre-warmed spawn chunks",
            w.level_name,
            w.level_type,
            w.seed,
            w.chunks.len()
        );
    }

    println!(
        "[trinitymax] booting {} cross-play world server (gamemode={}, difficulty={}, view-dist={}, sim-dist={})...",
        state.config.server_name(),
        state.config.gamemode_label(),
        state.config.get_str("difficulty", "hard"),
        state.config.view_distance(),
        state.config.simulation_distance()
    );
    println!("[trinitymax] java tcp       on {}:{} (Java 1.7.x - 1.26.x)", bind_ip, java_port);
    println!("[trinitymax] bedrock/pe udp on {}:{} (Bedrock 1.16.x - 26.x + PE 0.15.x)", bind_ip, bedrock_port);

    state.fire_event("on_server_start", state.config.server_name());

    let tcp_state = Arc::clone(&state);
    let udp_state = Arc::clone(&state);
    let tunnel_state = Arc::clone(&state);
    let java_ip = bind_ip.clone();
    let bedrock_ip = bind_ip;

    let tcp = tokio::spawn(run_java_tcp(java_ip, java_port, tcp_state));
    let udp = tokio::spawn(run_bedrock_udp(bedrock_ip, bedrock_port, udp_state));
    let tunnel = tokio::spawn(run_tunnel_client(tunnel_state));

    tcp.await??;
    udp.await??;
    tunnel.await??;
    Ok(())
}

async fn run_java_tcp(bind_ip: String, port: u16, state: Arc<ServerState>) -> Result<()> {
    let listener = TcpListener::bind((bind_ip.as_str(), port)).await?;
    loop {
        let (socket, peer) = listener.accept().await?;
        let conn_state = Arc::clone(&state);
        tokio::spawn(handle_java_connection(socket, peer, conn_state));
    }
}

async fn handle_java_connection(
    mut socket: TcpStream,
    peer: SocketAddr,
    state: Arc<ServerState>,
) -> Result<()> {
    socket.set_nodelay(true)?;
    let mut buf = [0u8; 512];
    let n = socket.read(&mut buf).await?;
    if n == 0 {
        return Ok(());
    }

    let mut pos = 0usize;
    let _packet_len = match read_varint(&buf[..n], &mut pos) {
        Some(v) => v,
        None => return Ok(()),
    };
    let packet_id = match read_varint(&buf[..n], &mut pos) {
        Some(v) => v,
        None => return Ok(()),
    };

    if packet_id == 0x00 {
        let protocol = match read_varint(&buf[..n], &mut pos) {
            Some(v) => v,
            None => return Ok(()),
        };
        let _server_addr = read_mc_string(&buf[..n], &mut pos);
        if pos + 2 <= n {
            pos += 2;
        }
        let next_state = read_varint(&buf[..n], &mut pos).unwrap_or(1);
        let ver_label = java_protocol_label(protocol);

        if next_state == 1 {
            if !state.config.enable_status() {
                return Ok(());
            }
            let status_version_name = if is_supported_java_protocol(protocol) {
                ver_label
            } else {
                "1.7.x-1.26.x"
            };
            let online = state.world.read().await.online_count();
            let motd_escaped = state.config.motd().replace('\n', "\\n");
            let status_json = format!(
                r#"{{"version":{{"name":"{}","protocol":{}}},"players":{{"max":{},"online":{}}},"description":{{"text":"{}"}}}}"#,
                status_version_name,
                protocol,
                state.config.max_players(),
                online,
                motd_escaped
            );
            let resp = build_java_string_packet(0x00, &status_json);
            socket.write_all(&resp).await?;
            socket.flush().await?;
            state.fire_event("on_java_ping", &peer.to_string());
        } else if next_state == 2 {
            let mut username = String::new();
            if pos < n {
                let _login_len = read_varint(&buf[..n], &mut pos);
                if read_varint(&buf[..n], &mut pos) == Some(0x00) {
                    username = read_mc_string(&buf[..n], &mut pos).unwrap_or_default();
                }
            } else if let Ok(m) = socket.read(&mut buf).await {
                if m > 0 {
                    let mut lpos = 0;
                    let _login_len = read_varint(&buf[..m], &mut lpos);
                    if read_varint(&buf[..m], &mut lpos) == Some(0x00) {
                        username = read_mc_string(&buf[..m], &mut lpos).unwrap_or_default();
                    }
                }
            }

            if !is_supported_java_protocol(protocol) {
                let kick = format!(
                    r#"{{"text":"§cUnsupported Java version (protocol {}). Supported: 1.7.x - 1.26.x"}}"#,
                    protocol
                );
                let pkt = build_java_string_packet(0x00, &kick);
                socket.write_all(&pkt).await?;
                socket.flush().await?;
                return Ok(());
            }

            if !username.is_empty() && !state.is_whitelisted(&username) {
                println!(
                    "[java] {} rejected non-whitelisted player '{}'",
                    peer, username
                );
                state.fire_event("on_login_denied", &username);
                let kick = format!(
                    r#"{{"text":"§cYou are not whitelisted on {}!"}}"#,
                    state.config.server_name()
                );
                let pkt = build_java_string_packet(0x00, &kick);
                socket.write_all(&pkt).await?;
                socket.flush().await?;
                return Ok(());
            }

            let player_name = if username.is_empty() {
                format!("JavaPlayer_{}", peer.port())
            } else {
                username
            };

            let spawn_chunk = {
                let mut w = state.world.write().await;
                let session = w.join_player(
                    player_name.clone(),
                    ClientPlatform::Java,
                    protocol,
                    peer.to_string(),
                );
                let cx = (session.x.floor() as i32) >> 4;
                let cz = (session.z.floor() as i32) >> 4;
                w.get_or_generate_chunk(cx, cz)
            };

            if requires_1_18_plus_crypto(protocol) {
                println!(
                    "[world][Java] '{}' joined ({}, proto {}) at spawn chunk ({}, {}) top={} [1.18+ crypto path]",
                    player_name, ver_label, protocol, spawn_chunk.cx, spawn_chunk.cz, spawn_chunk.top_block
                );
            } else {
                println!(
                    "[world][Java] '{}' joined ({}, proto {}) at spawn chunk ({}, {}) top={} [1.16/legacy chunk slicer]",
                    player_name, ver_label, protocol, spawn_chunk.cx, spawn_chunk.cz, spawn_chunk.top_block
                );
            }
            state.fire_event("on_player_join", &player_name);
        }
    }
    Ok(())
}

fn read_varint(buf: &[u8], pos: &mut usize) -> Option<i32> {
    let mut result: i32 = 0;
    for i in 0..5 {
        let byte = *buf.get(*pos)?;
        *pos += 1;
        result |= ((byte & 0x7F) as i32) << (7 * i);
        if byte & 0x80 == 0 {
            return Some(result);
        }
    }
    None
}

fn read_mc_string(buf: &[u8], pos: &mut usize) -> Option<String> {
    let len = read_varint(buf, pos)? as usize;
    if *pos + len > buf.len() {
        return None;
    }
    let s = String::from_utf8_lossy(&buf[*pos..*pos + len]).to_string();
    *pos += len;
    Some(s)
}

fn write_varint(buf: &mut Vec<u8>, mut value: i32) {
    loop {
        if (value & !0x7F) == 0 {
            buf.push(value as u8);
            return;
        }
        buf.push(((value & 0x7F) | 0x80) as u8);
        value = ((value as u32) >> 7) as i32;
    }
}

fn build_java_string_packet(packet_id: u8, payload: &str) -> Vec<u8> {
    let mut inner = Vec::new();
    write_varint(&mut inner, packet_id as i32);
    write_varint(&mut inner, payload.len() as i32);
    inner.extend_from_slice(payload.as_bytes());

    let mut full = Vec::new();
    write_varint(&mut full, inner.len() as i32);
    full.extend_from_slice(&inner);
    full
}

async fn run_bedrock_udp(bind_ip: String, port: u16, state: Arc<ServerState>) -> Result<()> {
    let socket = Arc::new(UdpSocket::bind((bind_ip.as_str(), port)).await?);
    let mut buf = [0u8; 2048];
    loop {
        let (len, peer) = socket.recv_from(&mut buf).await?;
        if len == 0 {
            continue;
        }
        if (buf[0] == 0x01 || buf[0] == 0x02) && len >= 9 {
            if !state.config.enable_status() {
                continue;
            }
            let mut time_bytes = [0u8; 8];
            time_bytes.copy_from_slice(&buf[1..9]);
            let ping_time = u64::from_be_bytes(time_bytes);
            let online = state.world.read().await.online_count();
            let pong = build_raknet_pong(ping_time, SERVER_GUID, &state.config, port, online);
            socket.send_to(&pong, peer).await?;
            println!(
                "[bedrock/pe] pong -> {} ({})",
                peer,
                bedrock_protocol_label(766)
            );
            state.fire_event("on_bedrock_ping", &peer.to_string());
        } else if buf[0] == 0x05 && len >= 18 {
            // RakNet Open Connection Request 1 (Bedrock & PE 0.15+)
            let rak_proto = if len >= 18 { buf[17] as i32 } else { 7 };
            let platform = classify_bedrock_platform(rak_proto);
            let player_name = format!("{}_{}", platform.as_str(), peer.port());
            let chunk = {
                let mut w = state.world.write().await;
                let s = w.join_player(
                    player_name.clone(),
                    platform,
                    rak_proto,
                    peer.to_string(),
                );
                let cx = (s.x.floor() as i32) >> 4;
                let cz = (s.z.floor() as i32) >> 4;
                w.get_or_generate_chunk(cx, cz)
            };
            println!(
                "[world][{}] '{}' connected via RakNet on {} (chunk {}, {})",
                platform.as_str(),
                player_name,
                peer,
                chunk.cx,
                chunk.cz
            );
            state.fire_event("on_player_join", &player_name);
        }
    }
}

fn build_raknet_pong(
    ping_time: u64,
    guid: u64,
    cfg: &ServerConfig,
    port: u16,
    online: usize,
) -> Vec<u8> {
    let _ = bedrock_protocol_label(766);
    let motd = format!(
        "MCPE;{};766;1.21.50;{};{};{};{};1;{};{};",
        cfg.bedrock_line1(),
        online,
        cfg.max_players(),
        guid,
        cfg.bedrock_line2(),
        cfg.gamemode_label(),
        port,
        cfg.bedrock_port_v6()
    );
    let mut pong = Vec::with_capacity(40 + motd.len());
    pong.push(0x1c);
    pong.extend_from_slice(&ping_time.to_be_bytes());
    pong.extend_from_slice(&RAKNET_MAGIC);
    pong.extend_from_slice(&guid.to_be_bytes());
    pong.extend_from_slice(&(motd.len() as u16).to_be_bytes());
    pong.extend_from_slice(motd.as_bytes());
    pong
}

async fn run_tunnel_client(state: Arc<ServerState>) -> Result<()> {
    loop {
        if state.config.enable_tunnel() {
            println!("[tunnel] heartbeat (stub)");
        }
        sleep(Duration::from_secs(30)).await;
    }
}
