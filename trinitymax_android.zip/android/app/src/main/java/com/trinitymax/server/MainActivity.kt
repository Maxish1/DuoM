package com.trinitymax.server

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import java.io.File

class MainActivity : Activity() {

    private lateinit var statusText: TextView
    private lateinit var propsEditor: EditText
    private lateinit var propsFile: File

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        propsEditor = findViewById(R.id.propsEditor)
        val reloadButton = findViewById<Button>(R.id.reloadPropsButton)
        val saveButton = findViewById<Button>(R.id.savePropsButton)

        propsFile = File(filesDir, "server.properties")

        statusText.text = "Starting TrinityMax server..."
        RustBridge().startServer()
        statusText.text = "TrinityMax running on TCP 25565 / UDP 19132"

        loadPropsIntoEditor()

        reloadButton.setOnClickListener {
            loadPropsIntoEditor()
            statusText.text = "Reloaded server.properties from disk"
        }

        saveButton.setOnClickListener {
            try {
                propsFile.writeText(propsEditor.text.toString())
                statusText.text = "Saved server.properties (restart app to apply port/IP/world changes)"
            } catch (e: Exception) {
                statusText.text = "Failed to save server.properties: ${e.message}"
            }
        }
    }

    private fun loadPropsIntoEditor() {
        if (propsFile.exists()) {
            propsEditor.setText(propsFile.readText())
        } else {
            propsEditor.setText("")
        }
    }
}
